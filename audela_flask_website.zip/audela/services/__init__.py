"""Service layer.

Keep BI logic out of route handlers.
"""

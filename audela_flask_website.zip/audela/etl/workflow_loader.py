from __future__ import annotations

from typing import Any, Dict
import json

def normalize_workflow(workflow: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(workflow, dict):
        raise ValueError("workflow must be a dict")
    if "steps" not in workflow or not isinstance(workflow["steps"], list):
        raise ValueError("workflow.steps must be a list")
    if "name" not in workflow:
        workflow["name"] = "unnamed_workflow"
    # Ensure each step has type/config
    for i, s in enumerate(workflow["steps"]):
        if "type" not in s:
            raise ValueError(f"step[{i}] missing type")
        s.setdefault("id", f"step_{i+1}")
        s.setdefault("config", {})
    return workflow

def workflow_to_json(workflow: Dict[str, Any]) -> str:
    return json.dumps(workflow, ensure_ascii=False, indent=2)
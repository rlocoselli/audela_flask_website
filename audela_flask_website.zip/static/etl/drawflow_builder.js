const editor = new Drawflow(document.getElementById("drawflow"));
editor.start();

function addNode(type) {

    const nodeId = editor.addNode(
        type,
        1,
        1,
        100,
        100,
        type,
        { type: type },
        `<div>
            <strong>${type}</strong>
            <div style="font-size:11px;color:#666">Config in backend</div>
         </div>`
    );

    console.log("Node added:", nodeId);
}

function saveWorkflow() {

    const workflow = editor.export();

    fetch("/etl/api/workflows", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(workflow)
    })
    .then(res => res.json())
    .then(data => {
        alert("Workflow saved successfully!");
        console.log(data);
    })
    .catch(err => {
        console.error(err);
        alert("Error saving workflow");
    });
}

function runWorkflow() {
  const wf = editor.export();
  fetch("/etl/api/run", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(wf)
  })
  .then(r => r.json())
  .then(data => {
    console.log("Run result:", data);
    alert("Workflow executed. Check logs/console.");
  })
  .catch(err => {
    console.error(err);
    alert("Error executing workflow");
  });
}
